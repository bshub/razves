<?php
// Heading
$_['heading_title']    = 'Редактор языков';

// Text
$_['text_success']     = 'Настройки успешно изменены!';
$_['text_edit']        = 'Редактирование';
$_['text_default']     = 'По умолчанию';
$_['text_store']       = 'Магазин';
$_['text_language']    = 'Язык';
$_['text_translation'] = 'Выбрать перевод';
$_['text_translation'] = 'Выбрать перевод';

// Entry
$_['entry_key']        = 'Ключ';
$_['entry_value']      = 'Значение';
$_['entry_default']    = 'По умолчанию';

// Error
$_['error_permission'] = 'У Вас нет прав для изменения настроек!';

