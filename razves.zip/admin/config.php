<?php
// HTTP
define('HTTP_SERVER', 'http://razves.loc/admin/');
define('HTTP_CATALOG', 'http://razves.loc/');

// HTTPS
define('HTTPS_SERVER', 'http://razves.loc/admin/');
define('HTTPS_CATALOG', 'http://razves.loc/');

// DIR
define('DIR_APPLICATION', '/var/www/razves/admin/');
define('DIR_SYSTEM', '/var/www/razves/system/');
define('DIR_IMAGE', '/var/www/razves/image/');
define('DIR_LANGUAGE', '/var/www/razves/admin/language/');
define('DIR_TEMPLATE', '/var/www/razves/admin/view/template/');
define('DIR_CONFIG', '/var/www/razves/system/config/');
define('DIR_CACHE', '/var/www/razves/system/storage/cache/');
define('DIR_DOWNLOAD', '/var/www/razves/system/storage/download/');
define('DIR_LOGS', '/var/www/razves/system/storage/logs/');
define('DIR_MODIFICATION', '/var/www/razves/system/storage/modification/');
define('DIR_UPLOAD', '/var/www/razves/system/storage/upload/');
define('DIR_CATALOG', '/var/www/razves/catalog/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'password');
define('DB_DATABASE', 'razves_bs_db');
define('DB_PORT', '3306');
define('DB_PREFIX', 'oc_');
